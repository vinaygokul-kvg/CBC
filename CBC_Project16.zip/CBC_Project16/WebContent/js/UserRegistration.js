function validateForm() {
	
	
	
	if( document.myForm.firstname.value == "" ) {
         alert( "Please provide your firstname!" );
         document.myForm.firstname.focus() ;
         document.getElementById("firstname").style.borderColor="red";
        
          return false;
	   
	}
	
	if( document.myForm.lastname.value == "" ) {
        alert( "Please provide your lastname!" );
        document.myForm.lastname.focus() ;
        document.getElementById("lastname").style.borderColor="red";
       
         return false;
	   
	}
	
	if( document.myForm.age.value == "" || isNaN(document.myForm.age.value)) {
        alert( "Please provide Valid Age!" );
         document.myForm.age.focus() ;
         return false;
      }

    if( document.myForm.contactnumber.value == "" || isNaN( document.myForm.contactnumber.value ) ||
       document.myForm.contactnumber.value.length != 10 ) {
       
      alert( "Please provide a 10-digit Contact Number" );
       document.myForm.contactnumber.focus() ;
        return false;
     }
	

    if( document.myForm.city.value == "" ) {
      alert( "Please provide your city!" );
      document.myForm.city.focus() ;
                                           document.getElementById("city").style.borderColor="red";
       return false;
    }              
    

    if( document.myForm.state.value == "" ) {
      alert( "Please provide your state!" );
      document.myForm.state.focus() ;
                                           document.getElementById("state").style.borderColor="red";
       return false;
    }              
    
	if( document.myForm.userid.value == "" ) {
        alert( "Please provide your userid!" );
        document.myForm.userid.focus() ;
        document.getElementById("userid").style.borderColor="red";
       
         return false;
	   
	}
	
	if( document.myForm.password.value == "" ) {
        alert( "Please provide your password!" );
        document.myForm.password.focus() ;
        document.getElementById("password").style.borderColor="red";
       
         return false;
	   
	}
	


    if( document.myForm.accno.value == "" || isNaN( document.myForm.accno.value ) ||
       document.myForm.accno.value.length != 16 ) {
       
      alert( "Please provide a 16-digit Account Number" );
       document.myForm.accno.focus() ;
        return false;
     }
}